import SwiftUI

@main
struct ALSResusApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
                .onAppear {
                    NotificationManager.shared.requestAuthorization()
                }
        }
    }
}
