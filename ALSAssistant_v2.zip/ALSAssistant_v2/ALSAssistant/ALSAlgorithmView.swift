import SwiftUI

struct ALSAlgorithmView: View {
    var body: some View {
        ScrollView {
            VStack {
                Image("ALSAlgorithm") // Add your ALS image in Assets.xcassets
                    .resizable()
                    .scaledToFit()
                    .padding()
            }
            .navigationTitle("ALS Algorithm")
        }
    }
}
