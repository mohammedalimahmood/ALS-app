import SwiftUI

struct HistoryView: View {
    var body: some View {
        Text("History of Resus Sessions (Core Data integration pending)")
            .padding()
    }
}
