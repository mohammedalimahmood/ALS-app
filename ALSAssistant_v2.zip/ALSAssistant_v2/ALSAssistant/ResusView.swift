import SwiftUI
import AVFoundation

struct ResusView: View {
    @State private var timer: Timer?
    @State private var timeElapsed: Int = 0
    @State private var events: [String] = []
    @State private var isRunning = false
    
    var body: some View {
        VStack {
            Text("ALS Timer")
                .font(.largeTitle)
                .padding()
            
            Text("\(timeElapsed / 60):\(String(format: "%02d", timeElapsed % 60))")
                .font(.system(size: 60))
                .padding()
            
            ScrollView(.horizontal) {
                HStack(spacing: 12) {
                    EventButton(title: "Shock", color: .red) { logEvent("Shock Delivered") }
                    EventButton(title: "Adrenaline", color: .blue) { logEvent("Adrenaline Given") }
                    EventButton(title: "Amiodarone", color: .orange) { logEvent("Amiodarone Given") }
                    EventButton(title: "Rhythm Check", color: .purple) { logEvent("Rhythm Check") }
                    EventButton(title: "Airway", color: .gray) { logEvent("Airway Secured") }
                    EventButton(title: "ROSC", color: .green) { logEvent("ROSC Achieved") }
                }
                .padding()
            }
            
            List(events, id: \.self) { event in
                Text(event)
            }
            
            HStack {
                Button(isRunning ? "Stop" : "Start") {
                    if isRunning {
                        stopTimer()
                    } else {
                        startTimer()
                    }
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(isRunning ? Color.red : Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
                
                NavigationLink(destination: SummaryView(events: events)) {
                    Text("Summary")
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .padding()
        }
        .onAppear {
            // Initialize reminders when resus starts
        }
        .navigationTitle("ALS Resus")
    }
    
    func startTimer() {
        isRunning = true
        NotificationManager.shared.scheduleReminders()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            timeElapsed += 1
        }
    }
    
    func stopTimer() {
        isRunning = false
        timer?.invalidate()
        NotificationManager.shared.cancelAll()
    }
    
    func logEvent(_ action: String) {
        let timeStamp = String(format: "%02d:%02d", timeElapsed / 60, timeElapsed % 60)
        events.append("\(timeStamp) - \(action)")
    }
}

struct EventButton: View {
    var title: String
    var color: Color
    var action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .padding()
                .background(color)
                .foregroundColor(.white)
                .cornerRadius(8)
        }
    }
}
